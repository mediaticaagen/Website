/* ==========================================================
   ABOUT.JS — page-specific behaviour for about.html
   Nothing custom needed yet beyond common.js (nav + menu).
   ========================================================== */

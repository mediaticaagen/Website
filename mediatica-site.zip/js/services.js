/* ==========================================================
   SERVICES.JS — page-specific behaviour for services.html
   Nothing custom needed yet beyond common.js (nav + menu).
   ========================================================== */

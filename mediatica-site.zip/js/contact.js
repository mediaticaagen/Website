/* ==========================================================
   CONTACT.JS — page-specific behaviour for contact.html
   Handles the sample contact form. Currently just shows a
   confirmation alert — replace the fetch()/alert block with a
   real request to your backend or a service like Formspree
   to actually send messages.
   ========================================================== */

document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('contactForm');
  if (!form) return;

  form.addEventListener('submit', (e) => {
    e.preventDefault();

    // TODO: replace this block with a real submission, e.g.:
    // fetch('https://formspree.io/f/YOUR_ID', { method: 'POST', body: new FormData(form) });

    alert('Thanks! This is a sample form — connect it to email or WhatsApp to go live.');
    form.reset();
  });
});

/* ==========================================================
   COMMON.JS — mobile menu toggle + active nav link highlight
   Included on every page.
   ========================================================== */

document.addEventListener('DOMContentLoaded', () => {
  const drawer = document.getElementById('drawer');
  const overlay = document.getElementById('overlay');
  const burger = document.getElementById('burger');

  function openDrawer(){ drawer.classList.add('open'); overlay.classList.add('open'); }
  function closeDrawer(){ drawer.classList.remove('open'); overlay.classList.remove('open'); }

  if (burger) {
    burger.addEventListener('click', () => {
      drawer.classList.contains('open') ? closeDrawer() : openDrawer();
    });
  }
  if (overlay) {
    overlay.addEventListener('click', closeDrawer);
  }
  // close drawer when a link inside it is tapped
  document.querySelectorAll('.mobile-drawer a').forEach(a => {
    a.addEventListener('click', closeDrawer);
  });

  // highlight the current page in both navbars based on the file name
  const current = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('nav.links a, .mobile-drawer a').forEach(a => {
    const href = a.getAttribute('href');
    if (href === current) a.classList.add('active');
  });
});

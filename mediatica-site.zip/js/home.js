/* ==========================================================
   HOME.JS — page-specific behaviour for index.html
   Nothing custom needed yet beyond common.js (nav + menu).
   Add home-only interactivity here as the page grows.
   ========================================================== */
